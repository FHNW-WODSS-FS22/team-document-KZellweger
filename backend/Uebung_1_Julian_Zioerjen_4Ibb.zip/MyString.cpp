#include "MyString.h"
#include "stdafx.h"

using namespace std;

// ----------------------------
// START KONSTRUKTOREN
// - String
// - String&& s
// - String& s
// - char* c
// - ~String
// ----------------------------


String::String(){
	m_len = 0;
	m_start = 0;
	m_string = nullptr;
}


String::String(String&& s){
	m_len = s.m_len;
	m_start = s.m_start;
	m_string = s.m_string;

	s.m_len = 0;
	s.m_start = 0;
	s.m_string = nullptr;
}

String::String(const String& s) : m_len(s.m_len), m_start(s.m_start), m_string(s.m_string){}

String::String(const char* c){
	m_len = 0;
	m_start = 0;

	while (c[m_len] != '\0') m_len++;

	m_string = shared_ptr<char>(unique_ptr<char[]>(new char[m_len]));
	for (int i = 0; i < m_len; i++){
		m_string.get()[i] = c[i];
	}
}

String::~String(){
	m_len = 0;
	m_start = 0;
	m_string = nullptr;
}

// ----------------------------
// ENDE KONSTRUKTOREN
// ----------------------------

// ----------------------------
// START METHODEN
// - charAt(size_t index)
// - compareTo(String& s)
// - concat(char c)
// - concat(String& s)
// - length()
// - substring(size_t beg,size_t end)
// - toCSString()
// - valueOf(int i)
// ----------------------------


char String::charAt(size_t index) const{
	if (index >= m_len) throw out_of_range("Index zu gross");
	return *(m_string.get() + index);
}

int String::compareTo(const String& s) const{

	int sameSignCounter = 0;
	int minLen = m_len > s.m_len ? m_len : s.m_len;

	while (m_string.get()[sameSignCounter] == s.m_string.get()[sameSignCounter] && sameSignCounter < minLen){
		sameSignCounter++;
	}


	if (s.m_string.get()[sameSignCounter] < m_string.get()[sameSignCounter])
		return 1;

	if (s.m_string.get()[sameSignCounter] > m_string.get()[sameSignCounter])
		return -1;

	return 0;

}

String String::concat(char c) const{
	shared_ptr<char> new_m_string = shared_ptr<char>(unique_ptr<char[]>(new char[m_len + 1]));

	for (int i = 0; i < m_len; i++){
		new_m_string.get()[i] = m_string.get()[i];
	}

	new_m_string.get()[m_len] = c;

	String newString;
	newString.m_string = new_m_string;
	newString.m_len = m_len + 1;
	newString.m_start = m_start;

	return newString;

}
String String::concat(const String& s) const{
	shared_ptr<char> new_m_string = shared_ptr<char>(unique_ptr<char[]>(new char[m_len + s.m_len]));

	for (int i = 0; i < m_len; i++){
		new_m_string.get()[i] = m_string.get()[i];
	}

	for (int i = 0; i < s.m_len; i++){
		new_m_string.get()[m_len + i] = m_string.get()[i];
	}

	String newString;
	newString.m_string = new_m_string;
	newString.m_len = m_len + s.m_len;
	newString.m_start = m_start;

	return newString;
}
size_t String::length() const {
	return m_len;
}
String String::substring(size_t beg, size_t end) const {

	if ((beg >= m_len || end <= beg)){
		return String();
	}

	//String newStr = String(*this);
	String newStr;
	//shared_ptr<char> new_m_string = shared_ptr<char>(unique_ptr<char[]>(new char[end - beg]));

	newStr.m_string = shared_ptr<char>(unique_ptr<char[]>(new char[end - beg]));
	for (int i = 0; i < (end - beg); i++){
		newStr.m_string.get()[i] = m_string.get()[beg + i];
	}

	//newStr.m_string = new_m_string;
	newStr.m_start = 0;
	newStr.m_len = end - beg;

	return newStr;
}

unique_ptr<char[]> String::toCString() const {
	unique_ptr<char[]> r = unique_ptr<char[]>(new char[m_len + 1]);
	const char * const tc = m_string.get();
	for (size_t i = 0; i < m_len; i++) r[i] = tc[m_start + i];
	// oder auch: memcpy(r.get(), tc + m_start, m_len); 
	r[m_len] = '\0';
	return move(r);
}

String String::valueOf(int i){
	int size = 1; // inclusive "\0"
	int val = i;
	int end = 0;
	bool isNegativ = (i < 0) ? true : false;


	int tmpVal = val;
	while (tmpVal > 0){
		size++;
		tmpVal = tmpVal / 10;
	}

	if (isNegativ){
		end = 1;
		size++;
	}

	shared_ptr<char> new_m_string = shared_ptr<char>(unique_ptr<char[]>(new char[size]));

	for (int i = size - 2; i >= end; i--){
		new_m_string.get()[i] = (val % 10) + '0';
		val = val / 10;
	}

	new_m_string.get()[size - 1] = '\0';

	if (isNegativ)
		new_m_string.get()[0] = '-';

	String newStr;
	newStr.m_string = new_m_string;
	newStr.m_len = size;

	return newStr;
}

// ----------------------------
// ENDE METHODEN
// ----------------------------

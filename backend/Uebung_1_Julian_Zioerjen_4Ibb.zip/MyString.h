#include <iostream>
#include <memory>

using namespace std;

class String final {

	// private Datenstuktur
	size_t m_len;
	char m_start;
	shared_ptr<char> m_string;

public:
	//�ffentliche Methoden
	String();
	String(const String& s);
	String::String(String&& s);
	String(const char* c);
	~String();

	// Instanz-Methoden  
	char charAt(size_t index) const;             // ung�ltiger Index -> Exception 
	int compareTo(const String& s) const;        // gibt -1, 0, 1 zur�ck 
	String concat(char c) const;                 // h�ngt c ans Ende und gibt neuen String zur�ck 
	String concat(const String& s) const;        // h�ngt s ans Ende und gibt neuen String zur�ck
	size_t length() const;                       // gibt die L�nge des Strings zur�ck 
	String substring(size_t beg, size_t end) const;
	unique_ptr<char[]> toCString() const;

	// Gleichheitsoperator (Inline-Implementation schon gegeben) 
	bool operator==(const String& s) const { return compareTo(s) == 0; }

	// Ausgabe-Operator f�r Output-Streams (Inline-Implementation schon gegeben) 
	friend ostream& operator<<(ostream& os, const String& s) {
		const size_t end = s.m_start + s.m_len;
		const char* const sc = s.m_string.get();
		for (size_t i = s.m_start; i < end; i++)
			os << sc[i];
		return os;
	}

	String& operator=(String&& s){
		m_len = s.m_len;
		m_start = s.m_start;
		m_string = s.m_string;

		s.m_len = 0;
		s.m_start = 0;
		s.m_string.reset();
		return *this;
	}

	// Klassen-Methode  
	static String valueOf(int i);               // erzeugt eine String-Repr�sentation von i 
};